using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChillLancer_RazorPage.Pages
{
    public class AuthenticationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

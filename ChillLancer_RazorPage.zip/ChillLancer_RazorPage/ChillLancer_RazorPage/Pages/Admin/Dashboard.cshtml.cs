using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChillLancer_RazorPage.Pages.Admin
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

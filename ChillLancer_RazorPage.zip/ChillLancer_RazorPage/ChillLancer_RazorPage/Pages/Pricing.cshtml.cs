using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChillLancer_RazorPage.Pages
{
    public class PricingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

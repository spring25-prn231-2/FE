using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChillLancer_RazorPage.Pages
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

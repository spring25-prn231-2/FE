using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChillLancer_RazorPage.Pages
{
    public class StarterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
